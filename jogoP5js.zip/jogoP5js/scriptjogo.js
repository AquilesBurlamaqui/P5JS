function setup() {
	createCanvas(640, 480);
	background(0);
}

function draw() {
	ellipse(50, 50, 80, 80);
}